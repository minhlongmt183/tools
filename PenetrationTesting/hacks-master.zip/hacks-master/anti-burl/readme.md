Takes URLs on stdin, prints them to stdout if they return a 200 OK. That's literally it ¯\\_(ツ)_/¯
